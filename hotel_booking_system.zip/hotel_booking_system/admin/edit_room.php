<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$room_id = isset($_GET['id']) ? $_GET['id'] : 0;
$error = "";

$stmt = mysqli_prepare($conn, "SELECT * FROM rooms WHERE room_id = ?");
mysqli_stmt_bind_param($stmt, "i", $room_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$room = mysqli_fetch_assoc($result);

if (!$room) {
    echo "<script>window.location.href='rooms.php';</script>";
    exit();
}

if (isset($_POST['update_room'])) {
    $room_type = $_POST['room_type'];
    $price = $_POST['price_per_night'];
    $status = $_POST['status'];

    $update_stmt = mysqli_prepare($conn, "UPDATE rooms SET room_type=?, price_per_night=?, status=? WHERE room_id=?");
    mysqli_stmt_bind_param($update_stmt, "sdsi", $room_type, $price, $status, $room_id);

    if (mysqli_stmt_execute($update_stmt)) {
        echo "<script>window.location.href='rooms.php';</script>";
        exit();
    } else {
        $error = "Error updating room.";
    }
}
?>

<div class="container-fluid pt-4 px-4">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-bottom-0">
                    <h4 class="fw-bold mb-0 text-warning"><i class="bi bi-pencil-square"></i> Edit Room</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase text-muted">Room Number</label>
                            <input type="text" class="form-control form-control-lg bg-light" value="<?php echo htmlspecialchars($room['room_number']); ?>" disabled>
                            <div class="form-text text-muted">Room number acts as a unique ID and cannot be changed.</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-uppercase text-muted">Room Type</label>
                                <select name="room_type" class="form-select">
                                    <option value="Single" <?php if($room['room_type']=='Single') echo 'selected'; ?>>Single</option>
                                    <option value="Double" <?php if($room['room_type']=='Double') echo 'selected'; ?>>Double</option>
                                    <option value="VIP" <?php if($room['room_type']=='VIP') echo 'selected'; ?>>VIP</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-uppercase text-muted">Price per Night ($)</label>
                                <input type="number" step="0.01" name="price_per_night" class="form-control" value="<?php echo $room['price_per_night']; ?>" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold small text-uppercase text-muted">Status</label>
                            <select name="status" class="form-select">
                                <option value="Available" <?php if($room['status']=='Available') echo 'selected'; ?>>Available</option>
                                <option value="Booked" <?php if($room['status']=='Booked') echo 'selected'; ?>>Booked</option>
                            </select>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="update_room" class="btn btn-warning btn-lg fw-bold text-dark">Update Changes</button>
                            <a href="rooms.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
