<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$query = "
    SELECT r.*, u.name, ro.room_number 
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    JOIN rooms ro ON r.room_id = ro.room_id
    ORDER BY r.created_at DESC
";
$result = mysqli_query($conn, $query);
?>

<div class="container-fluid pt-4 px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark">Customer Reviews</h2>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
             <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="py-3 ps-4">Date</th>
                            <th class="py-3">Customer</th>
                            <th class="py-3">Room</th>
                            <th class="py-3">Rating</th>
                            <th class="py-3 pe-4">Comment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr class="border-bottom">
                                    <td class="ps-4 text-muted small"><?php echo htmlspecialchars($row['created_at']); ?></td>
                                    <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['room_number']); ?></span>
                                    </td>
                                    <td>
                                        <?php 
                                            // Generate stars
                                            $rating = intval($row['rating']);
                                            for($i=0; $i<$rating; $i++) echo '<i class="bi bi-star-fill text-warning"></i>';
                                            for($i=$rating; $i<5; $i++) echo '<i class="bi bi-star text-muted"></i>';
                                        ?>
                                    </td>
                                    <td class="pe-4 text-muted fst-italic">"<?php echo htmlspecialchars($row['comment']); ?>"</td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No reviews found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php 
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
