<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$error = "";

if (isset($_POST['add_room'])) {
    $room_number = $_POST['room_number'];
    $room_type = $_POST['room_type'];
    $price = $_POST['price_per_night'];
    $status = $_POST['status'];

    // Check duplicate
    $check_query = "SELECT room_id FROM rooms WHERE room_number = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    
    if (!$check_stmt) {
        $error = "Prepare failed: " . mysqli_error($conn);
    } else {
        mysqli_stmt_bind_param($check_stmt, "s", $room_number);
        mysqli_stmt_execute($check_stmt);
        mysqli_stmt_store_result($check_stmt);

        if (mysqli_stmt_num_rows($check_stmt) > 0) {
            $error = "Room Number already exists!";
        } else {
            // Insert
            $insert_query = "INSERT INTO rooms (room_number, room_type, price_per_night, status) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insert_query);
            
            if (!$stmt) {
                $error = "Prepare failed: " . mysqli_error($conn);
            } else {
                mysqli_stmt_bind_param($stmt, "ssds", $room_number, $room_type, $price, $status);
                
                if (mysqli_stmt_execute($stmt)) {
                    echo "<script>window.location.href='rooms.php';</script>";
                    exit();
                } else {
                    $error = "Database Error: " . mysqli_error($conn);
                }
            }
        }
        mysqli_stmt_close($check_stmt);
    }
}
?>

<div class="container-fluid pt-4 px-4">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-header bg-white py-3 border-bottom-0">
                    <h4 class="fw-bold mb-0 text-primary">Add New Room</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger d-flex align-items-center" role="alert">
                            <i class="bi bi-exclamation-octagon-fill me-2"></i> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-uppercase text-muted">Room Number</label>
                            <input type="text" name="room_number" class="form-control form-control-lg" placeholder="e.g. 101" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-uppercase text-muted">Room Type</label>
                                <select name="room_type" class="form-select" required>
                                    <option value="Single">Single Room</option>
                                    <option value="Double">Double Room</option>
                                    <option value="VIP">VIP Suite</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-uppercase text-muted">Price per Night ($)</label>
                                <input type="number" step="0.01" name="price_per_night" class="form-control" placeholder="0.00" required>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold small text-uppercase text-muted">Initial Status</label>
                            <select name="status" class="form-select">
                                <option value="Available">Available</option>
                                <option value="Booked">Booked (Maintenance/Occupied)</option>
                            </select>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="add_room" class="btn btn-primary btn-lg fw-bold">Save Room</button>
                            <a href="rooms.php" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
