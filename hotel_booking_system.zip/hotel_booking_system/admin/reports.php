<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

// 1. Total Bookings
$total_bookings_query = mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings");
$total_bookings = ($total_bookings_query) ? mysqli_fetch_assoc($total_bookings_query)['count'] : 0;

// 2. Total Income (Confirmed Bookings)
$total_income_query = mysqli_query($conn, "SELECT SUM(total_price) as total FROM bookings WHERE payment_status = 'Paid'");
$total_income = ($total_income_query) ? mysqli_fetch_assoc($total_income_query)['total'] : 0;
$bookings_by_date_result = mysqli_query($conn, "SELECT DATE(check_in_date) as date, COUNT(*) as count, SUM(total_price) as revenue FROM bookings GROUP BY DATE(check_in_date) ORDER BY DATE(check_in_date) DESC LIMIT 30");
$room_status_result = mysqli_query($conn, "SELECT rooms.room_type, COUNT(bookings.booking_id) as booking_count FROM rooms LEFT JOIN bookings ON rooms.room_id = bookings.room_id GROUP BY rooms.room_type");
?>

<div class="container-fluid pt-4 px-4">
    <h2 class="fw-bold mb-4 text-dark">Analytics & Reports</h2>

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-3 bg-primary text-white h-100">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold text-white-50">Total Bookings (All Time)</h5>
                    <div class="display-4 fw-bold mt-2"><?php echo $total_bookings; ?></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-3 bg-success text-white h-100">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold text-white-50">Total Revenue (Confirmed)</h5>
                    <div class="display-4 fw-bold mt-2">$<?php echo number_format($total_income, 2); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Revenue Table -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-3 h-100">
                <div class="card-header bg-white py-3">
                    <h5 class="fw-bold mb-0">Daily Performance (Last 30 Days)</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0 align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Date</th>
                                    <th>Bookings</th>
                                    <th class="pe-4 text-end">Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($bookings_by_date_result): ?>
                                    <?php while ($row = mysqli_fetch_assoc($bookings_by_date_result)): ?>
                                        <tr>
                                            <td class="ps-4 fw-bold text-muted"><?php echo $row['date']; ?></td>
                                            <td><?php echo $row['count']; ?></td>
                                            <td class="pe-4 text-end text-success fw-bold">$<?php echo number_format($row['revenue'], 2); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" class="text-center py-3">No data available or error loading reports.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Room Popularity -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-3 h-100">
                <div class="card-header bg-white py-3">
                    <h5 class="fw-bold mb-0">Room Popularity</h5>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php while ($row = mysqli_fetch_assoc($room_status_result)): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center py-3 px-4">
                                <span class="fw-bold text-dark"><?php echo $row['room_type']; ?></span>
                                <span class="badge bg-primary rounded-pill px-3"><?php echo $row['booking_count']; ?> Bookings</span>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
