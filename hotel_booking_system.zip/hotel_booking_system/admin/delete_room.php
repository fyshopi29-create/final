<?php
session_start();
include "../config/db.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

if (isset($_GET['id'])) {
    $room_id = $_GET['id'];
    
    // Check if room exists
    $stmt = mysqli_prepare($conn, "SELECT room_id FROM rooms WHERE room_id = ?");
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $room_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            $del_stmt = mysqli_prepare($conn, "DELETE FROM rooms WHERE room_id = ?");
            if ($del_stmt) {
                mysqli_stmt_bind_param($del_stmt, "i", $room_id);
                if (mysqli_stmt_execute($del_stmt)) {
                    echo "<script>window.location.href='rooms.php';</script>";
                } else {
                    echo "Error deleting room: " . mysqli_error($conn);
                }
                mysqli_stmt_close($del_stmt);
            } else {
                echo "Prepare failed: " . mysqli_error($conn);
            }
        } else {
            echo "Room not found.";
        }
        mysqli_stmt_close($stmt);
    } else {
         echo "Prepare failed: " . mysqli_error($conn);
    }
} else {
    header("Location: rooms.php");
}
?>
