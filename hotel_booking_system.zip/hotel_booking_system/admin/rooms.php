<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

// Admin Check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$query = "SELECT * FROM rooms ORDER BY room_id DESC";
$result = mysqli_query($conn, $query);
?>

<div class="container-fluid pt-4 px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark">Manage Rooms</h2>
        <a href="add_room.php" class="btn btn-primary fw-bold"><i class="bi bi-plus-lg"></i> Add Room</a>
    </div>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="py-3 ps-4">Room No.</th>
                            <th class="py-3">Type</th>
                            <th class="py-3">Price</th>
                            <th class="py-3">Status</th>
                            <th class="py-3 text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr class="border-bottom">
                                    <td class="ps-4 fw-bold"><?php echo htmlspecialchars($row['room_number']); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border">
                                            <?php echo htmlspecialchars($row['room_type']); ?>
                                        </span>
                                    </td>
                                    <td class="fw-bold text-success">$<?php echo number_format($row['price_per_night'], 2); ?></td>
                                    <td>
                                        <?php if ($row['status'] == 'Available'): ?>
                                            <span class="badge bg-success rounded-pill px-3">Available</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill px-3">Booked</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="btn-group">
                                            <a href="edit_room.php?id=<?php echo $row['room_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil-square"></i> Edit</a>
                                            <a href="delete_room.php?id=<?php echo $row['room_id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this room?');"><i class="bi bi-trash"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center py-5 text-muted">No rooms found. Add one to get started.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php 
// Closing divs
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
