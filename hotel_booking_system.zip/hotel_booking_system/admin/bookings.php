<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$query = "SELECT b.booking_id, u.name as customer_name, r.room_number, b.check_in_date, b.check_out_date, b.booking_status, p.payment_status 
          FROM bookings b
          JOIN users u ON b.user_id = u.user_id
          JOIN rooms r ON b.room_id = r.room_id
          LEFT JOIN payments p ON b.booking_id = p.booking_id
          ORDER BY b.booking_id DESC";

$result = mysqli_query($conn, $query);
?>

<div class="container-fluid pt-4 px-4">
    <h2 class="fw-bold mb-4 text-dark">Manage Bookings</h2>
    
    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="py-3 ps-4">ID</th>
                            <th class="py-3">Customer</th>
                            <th class="py-3">Room</th>
                            <th class="py-3">Duration</th>
                            <th class="py-3">Status</th>
                            <th class="py-3">Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr class="border-bottom">
                                    <td class="ps-4 fw-bold text-muted">#<?php echo $row['booking_id']; ?></td>
                                    <td>
                                        <span class="fw-bold text-dark d-block"><?php echo htmlspecialchars($row['customer_name']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?php echo htmlspecialchars($row['room_number']); ?></span>
                                    </td>
                                    <td>
                                        <small class="d-block text-muted">In: <?php echo htmlspecialchars($row['check_in_date']); ?></small>
                                        <small class="d-block text-muted">Out: <?php echo htmlspecialchars($row['check_out_date']); ?></small>
                                    </td>
                                    <td>
                                        <?php 
                                        $status = $row['booking_status'];
                                        $badgeClass = 'bg-secondary';
                                        if ($status == 'Confirmed') $badgeClass = 'bg-success';
                                        if ($status == 'Pending') $badgeClass = 'bg-warning text-dark';
                                        if ($status == 'Cancelled') $badgeClass = 'bg-danger';
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?> rounded-pill px-3"><?php echo $status; ?></span>
                                    </td>
                                    <td>
                                        <?php if ($row['payment_status'] == 'Paid'): ?>
                                            <span class="text-success fw-bold"><i class="bi bi-check-circle-fill"></i> Paid</span>
                                        <?php else: ?>
                                            <span class="text-muted small">Pending</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">No bookings found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php 
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
