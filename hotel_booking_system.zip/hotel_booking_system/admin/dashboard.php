<?php
session_start();
include "../config/db.php";
include '../includes/admin_sidebar.php';

// 1. Admin Access Control
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$admin_name = isset($_SESSION['name']) ? $_SESSION['name'] : 'Admin';

// 2. Fetch Dashboard Stats
function fetch_count($conn, $sql) {
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        return $row['count'] ?? 0;
    }
    return 0;
}

$total_rooms = fetch_count($conn, "SELECT COUNT(*) as count FROM rooms");
$booked_rooms = fetch_count($conn, "SELECT COUNT(*) as count FROM rooms WHERE status='Booked'");
$available_rooms = $total_rooms - $booked_rooms;
$total_bookings = fetch_count($conn, "SELECT COUNT(*) as count FROM bookings");
$confirmed_bookings = fetch_count($conn, "SELECT COUNT(*) as count FROM bookings WHERE status = 'Confirmed'");
$cancelled_bookings = fetch_count($conn, "SELECT COUNT(*) as count FROM bookings WHERE status = 'Cancelled'");

// Total Income (Paid bookings)
$total_income = 0.00;
$income_query = "SELECT SUM(amount) as total FROM payments WHERE payment_status = 'Paid'";
$income_result = mysqli_query($conn, $income_query);
if ($income_result) {
    $row = mysqli_fetch_assoc($income_result);
    $total_income = $row['total'] ?? 0.00;
}
?>

<div class="container-fluid pt-4 px-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="fw-bold mb-0 text-dark">Dashboard</h2>
            <p class="text-muted">Welcome back, <?php echo htmlspecialchars($admin_name); ?>. Here's an overview of your hotel.</p>
        </div>
        <div>
            <a href="add_room.php" class="btn btn-primary fw-bold shadow-sm"><i class="bi bi-plus-lg"></i> Add New Room</a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <!-- Average Stats -->
        <div class="col-sm-6 col-xl-3">
            <div class="card bg-white border-0 shadow-sm h-100 rounded-3">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase fw-bold mb-1">Total Rooms</h6>
                        <h2 class="fw-bold mb-0 text-dark"><?php echo $total_rooms; ?></h2>
                        <small class="text-success fw-bold"><i class="bi bi-shop"></i> Total Inventory</small>
                    </div>
                    <div class="bg-light p-3 rounded-circle text-primary">
                        <i class="bi bi-building fs-3"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card bg-white border-0 shadow-sm h-100 rounded-3">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase fw-bold mb-1">Available Rooms</h6>
                        <h2 class="fw-bold mb-0 text-success"><?php echo $available_rooms; ?></h2>
                        <small class="text-muted">Ready for booking</small>
                    </div>
                    <div class="bg-light p-3 rounded-circle text-success">
                        <i class="bi bi-check-circle fs-3"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card bg-white border-0 shadow-sm h-100 rounded-3">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-muted text-uppercase fw-bold mb-1">Total Bookings</h6>
                        <h2 class="fw-bold mb-0 text-dark"><?php echo $total_bookings; ?></h2>
                        <small class="text-warning fw-bold"><i class="bi bi-clock-history"></i> <?php echo $confirmed_bookings; ?> Confirmed</small>
                    </div>
                    <div class="bg-light p-3 rounded-circle text-warning">
                        <i class="bi bi-journal-album fs-3"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card bg-primary text-white border-0 shadow-sm h-100 rounded-3">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 text-uppercase fw-bold mb-1">Total Income</h6>
                        <h2 class="fw-bold mb-0">$<?php echo number_format($total_income, 2); ?></h2>
                        <small class="text-white-50">Lifetime Revenue</small>
                    </div>
                    <div class="bg-white bg-opacity-25 p-3 rounded-circle text-white">
                        <i class="bi bi-currency-dollar fs-3"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions / Secondary Stats -->
    <div class="row g-4">
        <div class="col-md-6">
             <div class="card border-0 shadow-sm rounded-3 h-100">
                <div class="card-header bg-white py-3">
                    <h5 class="card-title mb-0 fw-bold">Booking Status Overview</h5>
                </div>
                 <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                        <span class="text-muted">Confirmed</span>
                        <span class="badge bg-success rounded-pill px-3"><?php echo $confirmed_bookings; ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded">
                        <span class="text-muted">Cancelled</span>
                        <span class="badge bg-danger rounded-pill px-3"><?php echo $cancelled_bookings; ?></span>
                    </div>
                    <!-- Placeholder for graph or more detailed lists can go here -->
                 </div>
             </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-info bg-gradient text-white border-0 shadow-sm rounded-3 h-100">
                <div class="card-body p-5 text-center">
                    <i class="bi bi-graph-up-arrow display-1 mb-3"></i>
                    <h3>Reports Center</h3>
                    <p>View detailed analytics for bookings and revenue.</p>
                    <a href="reports.php" class="btn btn-light fw-bold px-4 rounded-pill">View Reports</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// Closing divs for admin_sidebar.php container
echo "</div></div></div>"; 
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
