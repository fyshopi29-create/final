<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Note: This sidebar is designed to be included by files inside the 'admin/' directory.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Hotel Booking</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<div class="container-fluid">
    <div class="row min-vh-100 flex-nowrap">
        <!-- Sidebar -->
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark sidebar-sticky">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="dashboard.php" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none border-bottom w-100">
                    <span class="fs-5 d-none d-sm-inline fw-bold"><i class="bi bi-shield-lock"></i> Admin Panel</span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start w-100 mt-3" id="menu">
                    <li class="nav-item w-100 mb-2">
                        <a href="dashboard.php" class="nav-link text-white align-middle px-0 hover-effect">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item w-100 mb-2">
                        <a href="rooms.php" class="nav-link text-white align-middle px-0 hover-effect">
                            <i class="fs-4 bi-door-open"></i> <span class="ms-1 d-none d-sm-inline">Rooms</span>
                        </a>
                    </li>
                    <li class="nav-item w-100 mb-2">
                        <a href="bookings.php" class="nav-link text-white align-middle px-0 hover-effect">
                            <i class="fs-4 bi-journal-bookmark"></i> <span class="ms-1 d-none d-sm-inline">Bookings</span>
                        </a>
                    </li>
                    <li class="nav-item w-100 mb-2">
                        <a href="reports.php" class="nav-link text-white align-middle px-0 hover-effect">
                            <i class="fs-4 bi-bar-chart-line"></i> <span class="ms-1 d-none d-sm-inline">Reports</span>
                        </a>
                    </li>
                    <li class="nav-item w-100 mb-2">
                        <a href="reviews.php" class="nav-link text-white align-middle px-0 hover-effect">
                            <i class="fs-4 bi-chat-left-quote"></i> <span class="ms-1 d-none d-sm-inline">Reviews</span>
                        </a>
                    </li>
                </ul>
                <hr class="w-100 border-light">
                <div class="dropdown pb-4 w-100">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle fs-4"></i>
                        <span class="d-none d-sm-inline mx-1">Admin</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                        <li><a class="dropdown-item" href="../auth/logout.php">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Main Content Area Starts -->
        <div class="col py-3 main-content-wrapper">
