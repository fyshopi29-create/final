<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Note: This header is designed to be included by files inside the 'customer/' directory.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luxury Hotel | Experience Comfort</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .navbar-nav .nav-link {
            font-weight: 600;
            color: #333;
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover, .navbar-nav .nav-link.active {
            color: #0d6efd; 
        }
        .navbar-brand {
            letter-spacing: 0.5px;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top py-3">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand fw-bold text-primary fs-4" href="home.php">
            <i class="bi bi-buildings-fill me-2"></i>Luxury Hotel
        </a>

        <!-- Toggler for Mobile -->
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#hotelNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="hotelNavbar">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center gap-1 gap-lg-3">
                <li class="nav-item">
                    <a class="nav-link" href="home.php"><i class="bi bi-house-door me-1"></i> Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="rooms.php"><i class="bi bi-hospital me-1"></i> Rooms</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="my_bookings.php"><i class="bi bi-calendar-check me-1"></i> Bookings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"><i class="bi bi-info-circle me-1"></i> About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"><i class="bi bi-telephone me-1"></i> Contact</a>
                </li>

                <!-- Separator for desktop -->
                <li class="d-none d-lg-block border-end mx-2" style="height: 24px;"></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Account Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle btn btn-outline-primary border-0 rounded-pill px-3" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i> Account
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 mt-2">
                             <li><span class="dropdown-item-text text-muted small">Logged in as <?php echo htmlspecialchars($_SESSION['name'] ?? 'Client'); ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="../auth/logout.php"><i class="bi bi-box-arrow-right me-2"></i> Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <!-- Auth Buttons -->
                    <li class="nav-item">
                        <a href="../auth/login.php" class="btn btn-outline-primary fw-bold rounded-pill px-4 me-lg-2 w-100 mb-2 mb-lg-0">
                            <i class="bi bi-box-arrow-in-right me-1"></i> Login
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="../auth/register.php" class="btn btn-primary fw-bold rounded-pill px-4 w-100">
                            <i class="bi bi-person-plus me-1"></i> Register
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Content Wrapper starts here, to be closed in pages or footer -->
<div class="main-content flex-grow-1">
