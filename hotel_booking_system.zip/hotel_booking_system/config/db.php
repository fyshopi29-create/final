<?php
$host = "localhost";
$user = "root";
$password = "123";
$database = "hotel_booking_db";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
