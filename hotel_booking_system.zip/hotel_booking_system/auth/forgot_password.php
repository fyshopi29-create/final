<?php
session_start();
include "../config/db.php";

$msg = "";
$msg_type = "";

if (isset($_POST['reset_password'])) {
    $email = $_POST['email'];

    // Check if email exists
    $stmt = mysqli_prepare($conn, "SELECT email FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Security practice: Always show the same generic message whether email exists or not
    // to prevent email enumeration attacks.
    $msg = "If this email exists in our system, your password reset instructions have been sent.";
    $msg_type = "success";
    
    /* 
    // Ideally, here you would generate a token, save it to DB, and send an email.
    // Since we are frontend focused right now and avoiding backend modifications:
    if (mysqli_num_rows($result) > 0) {
        // Send email logic here
    }
    */
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Hotel Booking System</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="card border-0 shadow-lg rounded-4 text-center" style="max-width: 450px; width: 100%;">
        <div class="card-body p-4 p-md-5">
            
            <div class="mb-4 text-primary">
                <i class="bi bi-shield-lock display-3"></i>
            </div>
            
            <h3 class="fw-bold mb-2">Forgot Password?</h3>
            <p class="text-muted mb-4">No worries! Enter your email and we'll send you reset instructions.</p>

            <?php if ($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> text-start mb-4" role="alert">
                    <small><?php echo $msg; ?></small>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-floating mb-4 text-start">
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                    <label for="email">Enter your email</label>
                </div>

                <button type="submit" name="reset_password" class="btn btn-primary w-100 py-3 fw-bold shadow-sm mb-4">Send Reset Link</button>
                
                <a href="login.php" class="btn btn-link text-decoration-none text-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Back to Login
                </a>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
