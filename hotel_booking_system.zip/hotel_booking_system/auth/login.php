<?php
session_start();
include "../config/db.php";

$error = "";

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepared Statement for SQL Injection Prevention
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        if (password_verify($password, $user['password'])) {
             // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];

            if ($user['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: ../customer/home.php");
            }
            exit();

        } else {
            $error = "Incorrect password!";
        }
    } else {
        $error = "Email not found!";
    }
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Hotel Booking System</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
    <!-- Centered Card -->
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden" style="max-width: 450px; width: 100%;">
        
        <!-- Top Image Section -->
        <div class="position-relative" style="height: 220px;">
            <img src="../assets/images/hotelbooking.jpg" alt="Hotel" class="w-100 h-100 object-fit-cover">
            <!-- Overlay Text -->
            <div class="position-absolute bottom-0 start-0 w-100 p-4" style="background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);">
                <h4 class="text-white fw-bold mb-1">Welcome to Luxury Hotel</h4>
                <p class="text-white-50 mb-0 small">Please login to continue your booking</p>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">

            <?php if ($error): ?>
                <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                    <i class="bi bi-exclamation-circle-fill me-2"></i>
                    <small><?php echo $error; ?></small>
                </div>
            <?php endif; ?>

            <form method="POST" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="email" class="form-label text-muted small fw-bold">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control border-start-0 ps-0 bg-light" id="email" name="email" placeholder="name@example.com" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label text-muted small fw-bold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control border-start-0 ps-0 bg-light" id="password" name="password" placeholder="Enter password" required>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="rememberMe">
                        <label class="form-check-label text-muted small" for="rememberMe">Remember me</label>
                    </div>
                    <a href="forgot_password.php" class="text-decoration-none small fw-bold text-primary">Forgot password?</a>
                </div>

                <button type="submit" name="login" class="btn btn-primary w-100 py-2 fw-bold shadow-sm mb-4 rounded-3 text-uppercase" style="letter-spacing: 0.5px;">
                    Login <i class="bi bi-arrow-right-short ms-1"></i>
                </button>
                
                <div class="text-center pt-2 border-top">
                    <span class="text-muted small">Don't have an account?</span> 
                    <a href="register.php" class="text-decoration-none fw-bold small ms-1">Create an account</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
