<?php
session_start();
include "../config/db.php";

$msg = "";
$msg_type = "";

if (isset($_POST['register'])) {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $password_raw = $_POST['password']; 
    $confirm_password = $_POST['confirm_password'];

    if ($password_raw !== $confirm_password) {
        $msg = "Passwords do not match!";
        $msg_type = "danger";
    } else {
        $pass  = password_hash($password_raw, PASSWORD_DEFAULT); 

        // Check if email exists
        $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $msg = "Email already exists!";
            $msg_type = "warning";
        } else {
            // Prepared Insert
            $insert_stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'customer')");
            mysqli_stmt_bind_param($insert_stmt, "sss", $name, $email, $pass); 

            if (mysqli_stmt_execute($insert_stmt)) {
                 $msg = "Registration successful! You can now login.";
                 $msg_type = "success";
                 echo "<script>setTimeout(function(){ window.location.href='login.php'; }, 2000);</script>";
            } else {
                $msg = "Registration failed: " . mysqli_error($conn);
                $msg_type = "danger";
            }
            mysqli_stmt_close($insert_stmt);
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Hotel Booking System</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden" style="max-width: 500px; width: 100%;">
        <div class="card-header bg-primary text-white text-center py-4">
            <h3 class="fw-bold mb-0">Create Account</h3>
            <small>Join us to book your dream stay</small>
        </div>
        <div class="card-body p-4 p-md-5">
            <?php if ($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> d-flex align-items-center" role="alert">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    <div><?php echo $msg; ?></div>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
                    <label for="name">Full Name</label>
                </div>

                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                    <label for="email">Email Address</label>
                </div>

                <div class="row g-2 mb-4">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                            <label for="password">Password</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                            <label for="confirm_password">Confirm Password</label>
                        </div>
                    </div>
                </div>

                <button type="submit" name="register" class="btn btn-primary w-100 py-3 fw-bold shadow-sm mb-3">Create Free Account</button>
                
                <div class="text-center">
                    <span class="text-muted">Already have an account?</span> 
                    <a href="login.php" class="text-decoration-none fw-bold ms-1">Login Here</a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
