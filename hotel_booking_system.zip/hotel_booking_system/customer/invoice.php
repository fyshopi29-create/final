<?php
session_start();
include "../config/db.php";
// Note: Header not included here to keep Invoice clean for printing, or can be simple.
// We will use standard HTML for print-ready layout.

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    header("Location: ../auth/login.php");
    exit();
}

$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;
$user_id = $_SESSION['user_id'];

$query = "
    SELECT b.*, u.name as customer_name, u.email, r.room_number, r.room_type, r.price_per_night, p.amount as paid_amount, p.payment_method, p.payment_date 
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN rooms r ON b.room_id = r.room_id
    LEFT JOIN payments p ON b.booking_id = p.booking_id
    WHERE b.booking_id = ? AND b.user_id = ? AND b.booking_status = 'Confirmed'
";

$stmt = mysqli_prepare($conn, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "ii", $booking_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Database Error: " . mysqli_error($conn));
}
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Invoice not found or access denied.");
}

// Calculate nights
$d1 = new DateTime($data['check_in_date']);
$d2 = new DateTime($data['check_out_date']);
$nights = $d1->diff($d2)->days ?: 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #INV-<?php echo $booking_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background: #e9ecef; }
        .invoice-container { background: white; max-width: 800px; margin: 50px auto; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); padding: 40px; }
        @media print {
            body { background: white; }
            .invoice-container { box-shadow: none; border: none; margin: 0; padding: 20px; }
            .bg-light { background-color: #f8f9fa !important; -webkit-print-color-adjust: exact; }
            .btn, .no-print { display: none !important; }
        }
    </style>
</head>
<body>

<div class="invoice-container">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-5 pb-4 border-bottom">
        <div>
            <h2 class="fw-bold text-primary mb-0"><i class="bi bi-building"></i> Hotel Booking System</h2>
            <small class="text-muted">Experience luxury & comfort</small>
        </div>
        <div class="text-end">
            <h4 class="fw-bold mb-1">INVOICE</h4>
            <span class="text-muted">#INV-<?php echo str_pad($booking_id, 6, '0', STR_PAD_LEFT); ?></span>
        </div>
    </div>

    <!-- Info Sections -->
    <div class="row mb-5">
        <div class="col-6">
            <p class="small text-uppercase text-muted fw-bold mb-1">Billed To</p>
            <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($data['customer_name']); ?></h5>
            <p class="text-muted mb-0"><?php echo htmlspecialchars($data['email']); ?></p>
        </div>
        <div class="col-6 text-end">
            <div class="mb-2">
                <span class="small text-uppercase text-muted fw-bold">Date Issued:</span>
                <span class="fw-bold fs-6 ms-2"><?php echo date('M d, Y', strtotime($data['payment_date'])); ?></span>
            </div>
            <div>
                <span class="small text-uppercase text-muted fw-bold">Payment Method:</span>
                <span class="badge bg-light text-dark border ms-2"><?php echo htmlspecialchars($data['payment_method']); ?></span>
            </div>
        </div>
    </div>

    <!-- Table -->
    <table class="table table-bordered mb-4">
        <thead class="bg-light">
            <tr>
                <th class="py-3">Description</th>
                <th class="py-3 text-center">Nights</th>
                <th class="py-3 text-end">Price / Night</th>
                <th class="py-3 text-end">Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="py-3">
                    <span class="fw-bold d-block"><?php echo htmlspecialchars($data['room_type']); ?> Room</span>
                    <small class="text-muted">Room No: <?php echo htmlspecialchars($data['room_number']); ?></small><br>
                    <small class="text-muted">Check-in: <?php echo $data['check_in_date']; ?></small><br>
                    <small class="text-muted">Check-out: <?php echo $data['check_out_date']; ?></small>
                </td>
                <td class="text-center py-3 align-middle"><?php echo $nights; ?></td>
                <td class="text-end py-3 align-middle">$<?php echo number_format($data['price_per_night'], 2); ?></td>
                <td class="text-end py-3 align-middle fw-bold">$<?php echo number_format($data['paid_amount'], 2); ?></td>
            </tr>
        </tbody>
        <tfoot class="bg-light">
            <tr>
                <td colspan="3" class="text-end py-3 fw-bold">Grand Total</td>
                <td class="text-end py-3 fw-bold text-primary fs-5">$<?php echo number_format($data['paid_amount'], 2); ?></td>
            </tr>
        </tfoot>
    </table>

    <!-- Footer for Print -->
    <div class="text-center mt-5 pt-3 border-top text-muted small">
        <p class="mb-1">Thank you for staying with us!</p>
        <p>If you have any questions about this invoice, please contact support.</p>
    </div>

    <!-- Actions -->
    <div class="text-center mt-4 no-print d-flex justify-content-center gap-3">
        <button onclick="window.print()" class="btn btn-primary px-4 fw-bold"><i class="bi bi-printer"></i> Print Invoice</button>
        <a href="my_bookings.php" class="btn btn-outline-secondary px-4 fw-bold">Back to Bookings</a>
    </div>
</div>

</body>
</html>
