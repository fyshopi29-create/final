<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$error = "";
$success_redirect = false;

// GET Request: Show Confirmation Form
if ($_SERVER['REQUEST_METHOD'] == 'GET' && !isset($_POST['confirm_booking'])) {
    if (!isset($_GET['room_id']) || !isset($_GET['check_in']) || !isset($_GET['check_out'])) {
        echo "<script>window.location.href='rooms.php';</script>";
        exit();
    }

    $room_id = $_GET['room_id'];
    $check_in = $_GET['check_in'];
    $check_out = $_GET['check_out'];

    // Fetch Room Info
    $stmt = mysqli_prepare($conn, "SELECT * FROM rooms WHERE room_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $room_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $room = mysqli_fetch_assoc($result);
    
    if (!$room) {
        die("Invalid Room");
    }
}

// POST Request: Process Booking
if (isset($_POST['confirm_booking'])) {
    $room_id = $_POST['room_id'];
    $check_in = $_POST['check_in'];
    $check_out = $_POST['check_out'];
    $user_id = $_SESSION['user_id'];
    
    // Re-verify room info for display if error occurs
    $stmt = mysqli_prepare($conn, "SELECT * FROM rooms WHERE room_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $room_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $room = mysqli_fetch_assoc($result);

    // 1. Availability Check (Race Condition security)
    $check_query = "
        SELECT booking_id FROM bookings 
        WHERE room_id = ? 
        AND booking_status != 'Cancelled'
        AND (check_in_date < ? AND check_out_date > ?)
    ";
    $check_stmt = mysqli_prepare($conn, $check_query);
    if (!$check_stmt) {
        $error = "Database error: " . mysqli_error($conn);
    } else {
        mysqli_stmt_bind_param($check_stmt, "iss", $room_id, $check_out, $check_in);
        mysqli_stmt_execute($check_stmt);
        mysqli_stmt_store_result($check_stmt);

        if (mysqli_stmt_num_rows($check_stmt) > 0) {
            $error = "Sorry! This room was just booked by someone else.";
        } else {
            // 2. Insert Booking
            $insert = "INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, booking_status) VALUES (?, ?, ?, ?, 'Pending')";
            $stmt_ins = mysqli_prepare($conn, $insert);
            if (!$stmt_ins) {
                $error = "Database error: " . mysqli_error($conn);
            } else {
                mysqli_stmt_bind_param($stmt_ins, "iiss", $user_id, $room_id, $check_in, $check_out);
                
                if (mysqli_stmt_execute($stmt_ins)) {
                    $success_redirect = true;
                } else {
                    $error = "Booking failed: " . mysqli_error($conn);
                }
            }
        }
    }
}

if ($success_redirect) {
    echo "<script>window.location.href='my_bookings.php';</script>";
    exit();
}

// Prepare display variables (either from GET or POST fallback)
$d_check_in = isset($_POST['check_in']) ? $_POST['check_in'] : $_GET['check_in'];
$d_check_out = isset($_POST['check_out']) ? $_POST['check_out'] : $_GET['check_out'];

// Calc nights and price
$d1 = new DateTime($d_check_in);
$d2 = new DateTime($d_check_out);
$diff = $d1->diff($d2);
$nights = $diff->days > 0 ? $diff->days : 1;
$total = $nights * $room['price_per_night'];
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            
            <div class="card shadow border-0 rounded-3">
                <div class="card-header bg-primary text-white p-4">
                    <h4 class="mb-0 fw-bold"><i class="bi bi-calendar-check me-2"></i> Confirm Booking</h4>
                </div>
                
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger d-flex align-items-center mb-4" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                            <div><?php echo $error; ?></div>
                        </div>
                    <?php endif; ?>

                    <!-- Room Summary -->
                    <div class="d-flex align-items-center mb-4 pb-4 border-bottom">
                         <?php 
                            $img_src = '../assets/images/hotel.webp';
                            if (strpos($room['room_type'], 'Single') !== false) $img_src = '../assets/images/Single Room.jpg';
                            elseif (strpos($room['room_type'], 'Double') !== false) $img_src = '../assets/images/Double Room.webp';
                            elseif (strpos($room['room_type'], 'VIP') !== false) $img_src = '../assets/images/VIP Room.jpg';
                        ?>
                        <img src="<?php echo $img_src; ?>" alt="Room" class="rounded me-3" style="width: 80px; height: 80px; object-fit: cover;">
                        <div>
                            <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($room['room_type']); ?></h5>
                            <span class="text-muted small">Room No: <?php echo htmlspecialchars($room['room_number']); ?></span>
                        </div>
                    </div>

                    <!-- Booking Details Grid -->
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <div class="p-3 bg-light rounded text-center h-100 border">
                                <small class="text-muted text-uppercase fw-bold d-block mb-1">Check-in</small>
                                <span class="fs-5 fw-bold text-dark"><?php echo htmlspecialchars($d_check_in); ?></span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-3 bg-light rounded text-center h-100 border">
                                <small class="text-muted text-uppercase fw-bold d-block mb-1">Check-out</small>
                                <span class="fs-5 fw-bold text-dark"><?php echo htmlspecialchars($d_check_out); ?></span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-3 bg-light rounded text-center h-100 border">
                                <small class="text-muted text-uppercase fw-bold d-block mb-1">Stay</small>
                                <span class="fs-5 fw-bold text-dark"><?php echo $nights; ?> Night(s)</span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="p-3 bg-primary text-white rounded text-center h-100 shadow-sm">
                                <small class="text-white-50 text-uppercase fw-bold d-block mb-1">Total</small>
                                <span class="fs-5 fw-bold">$<?php echo number_format($total, 2); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Confirmation Form -->
                    <form method="POST">
                        <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                        <input type="hidden" name="check_in" value="<?php echo $d_check_in; ?>">
                        <input type="hidden" name="check_out" value="<?php echo $d_check_out; ?>">
                        <input type="hidden" name="total_price" value="<?php echo $total; ?>">
                        
                        <div class="d-grid gap-3">
                            <button type="submit" name="confirm_booking" class="btn btn-success btn-lg fw-bold shadow-sm">
                                <i class="bi bi-check-lg me-2"></i> Confirm & Book
                            </button>
                            <a href="room_details.php?id=<?php echo $room['room_id']; ?>&check_in=<?php echo $d_check_in; ?>&check_out=<?php echo $d_check_out; ?>" class="btn btn-outline-secondary fw-bold">
                                Back to Details
                            </a>
                        </div>
                    </form>

                </div>
            </div>
            
            <div class="text-center mt-3 text-muted small">
                <i class="bi bi-shield-lock-fill"></i> Your booking is secure. Payment will be collected in the next step.
            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
