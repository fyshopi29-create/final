<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

// 1. Payment Access Control
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

if (!isset($_GET['booking_id'])) {
    echo "<script>window.location.href='my_bookings.php';</script>";
    exit();
}

$booking_id = intval($_GET['booking_id']);
$user_id = $_SESSION['user_id'];
$error = "";

// 2. Fetch Booking Details
$query = "
    SELECT b.*, r.room_number, r.price_per_night, r.room_type,
           (SELECT COUNT(*) FROM payments p WHERE p.booking_id = b.booking_id) as payment_count
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    WHERE b.booking_id = ? AND b.user_id = ?
";

$stmt = mysqli_prepare($conn, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "ii", $booking_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Database Error: " . mysqli_error($conn)); 
}
$booking = mysqli_fetch_assoc($result);

if (!$booking) {
    echo "<div class='container my-5'><div class='alert alert-danger'>Invalid Booking ID.</div></div>";
    include '../includes/footer.php';
    exit();
}

if ($booking['payment_count'] > 0 || $booking['booking_status'] == 'Confirmed') {
    echo "<script>window.location.href='payment_success.php?booking_id=$booking_id';</script>";
    exit();
}

$d1 = new DateTime($booking['check_in_date']);
$d2 = new DateTime($booking['check_out_date']);
$nights = $d1->diff($d2)->days ?: 1;
$amount = $nights * $booking['price_per_night'];

// 3. Process Payment
if (isset($_POST['pay_now'])) {
    $payment_method = $_POST['payment_method'];
    $valid_methods = ['Cash', 'EVC Plus', 'SahalPay'];
    
    if (in_array($payment_method, $valid_methods)) {
        mysqli_begin_transaction($conn);
        try {
            // A. Insert Payment
            $pay_query = "INSERT INTO payments (booking_id, amount, payment_method, payment_status, payment_date) VALUES (?, ?, ?, 'Paid', NOW())";
            $pay_stmt = mysqli_prepare($conn, $pay_query);
            mysqli_stmt_bind_param($pay_stmt, "ids", $booking_id, $amount, $payment_method);
            mysqli_stmt_execute($pay_stmt);
            
            // B. Update Booking Status
            $update_query = "UPDATE bookings SET booking_status = 'Confirmed' WHERE booking_id = ?";
            $upd_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($upd_stmt, "i", $booking_id);
            mysqli_stmt_execute($upd_stmt);
            
            mysqli_commit($conn);
            
            // Send Email (Simulated)
            $to = $_SESSION['email'] ?? "customer@example.com";
            $subject = "Payment Confirmed - Booking #$booking_id";
            $body = "Thank you! payment received.";
            @mail($to, $subject, $body, "From: no-reply@hotel.com");
            
            echo "<script>window.location.href='payment_success.php?booking_id=$booking_id';</script>";
            exit();
            
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Payment failed: " . $e->getMessage();
        }
    } else {
        $error = "Invalid payment method selected.";
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow border-0 rounded-3">
                <div class="card-header bg-success text-white p-4">
                    <h4 class="mb-0 fw-bold"><i class="bi bi-credit-card-2-front me-2"></i> Secure Payment</h4>
                </div>
                <div class="card-body p-4">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <div class="text-center mb-4">
                        <span class="text-muted text-uppercase small fw-bold">Total Amount to Pay</span>
                        <h1 class="text-success fw-bold display-4 my-2">$<?php echo number_format($amount, 2); ?></h1>
                        <span class="badge bg-light text-dark border">Booking ID: #<?php echo $booking_id; ?></span>
                    </div>

                    <div class="list-group mb-4 shadow-sm">
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Room Type</span>
                            <span class="fw-bold"><?php echo htmlspecialchars($booking['room_type']); ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Check-in</span>
                            <span class="fw-bold"><?php echo $booking['check_in_date']; ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Duration</span>
                            <span class="fw-bold"><?php echo $nights; ?> Night(s)</span>
                        </div>
                    </div>

                    <form method="POST">
                        <div class="mb-4">
                            <label class="form-label fw-bold">Select Payment Method</label>
                            <select name="payment_method" class="form-select form-select-lg" required>
                                <option value="">-- Choose Method --</option>
                                <option value="EVC Plus">EVC Plus (Mobile Money)</option>
                                <option value="SahalPay">SahalPay (Mobile Money)</option>
                                <option value="Cash">Cash at Hotel</option>
                            </select>
                            <div class="form-text mt-2"><i class="bi bi-info-circle"></i> Secure transaction simulation.</div>
                        </div>

                        <div class="d-grid">
                            <button type="submit" name="pay_now" class="btn btn-success btn-lg fw-bold shadow-sm">
                                Pay Now <i class="bi bi-arrow-right-short"></i>
                            </button>
                            <a href="my_bookings.php" class="btn btn-link text-secondary mt-2">Cancel Transaction</a>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <img src="https://cdn-icons-png.flaticon.com/512/196/196566.png" alt="Secure" style="height: 30px; opacity: 0.5">
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
