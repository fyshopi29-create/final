<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5 text-center">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-body p-5">
                    <div class="mb-4">
                        <div class="d-inline-block p-4 rounded-circle bg-success bg-opacity-10 text-success mb-3">
                            <i class="bi bi-check-circle-fill display-1"></i>
                        </div>
                    </div>
                    
                    <h2 class="fw-bold text-success mb-3">Payment Successful!</h2>
                    <p class="text-muted lead mb-4">Your booking has been confirmed securely.</p>
                    
                    <div class="bg-light p-3 rounded mb-4">
                        <p class="mb-1 text-muted small text-uppercase fw-bold">Booking Reference</p>
                        <h3 class="font-monospace text-dark mb-0">#<?php echo $booking_id; ?></h3>
                    </div>

                    <div class="d-grid gap-3">
                        <a href="invoice.php?booking_id=<?php echo $booking_id; ?>" target="_blank" class="btn btn-dark btn-lg fw-bold">
                            <i class="bi bi-file-earmark-pdf me-2"></i> Download Invoice
                        </a>
                        <a href="my_bookings.php" class="btn btn-outline-primary btn-lg fw-bold">
                            View My Bookings
                        </a>
                    </div>
                </div>
                <div class="card-footer bg-light p-3 small text-muted">
                    We've sent a confirmation email to your inbox.
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
