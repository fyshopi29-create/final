<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

if (!isset($_GET['id'])) {
    echo "<script>window.location.href='rooms.php';</script>";
    exit();
}

$room_id = $_GET['id'];
$query = "SELECT * FROM rooms WHERE room_id = ?";
$stmt = mysqli_prepare($conn, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $room_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Database Error: " . mysqli_error($conn));
}

if (mysqli_num_rows($result) == 0) {
    echo "<script>window.location.href='rooms.php';</script>";
    exit();
}

$room = mysqli_fetch_assoc($result);

// Pre-fill dates if available
$pre_check_in = isset($_GET['check_in']) ? $_GET['check_in'] : date('Y-m-d');
$pre_check_out = isset($_GET['check_out']) ? $_GET['check_out'] : date('Y-m-d', strtotime('+1 day'));

// Determine Image
$img_src = '../assets/images/hotel.webp';
if (strpos($room['room_type'], 'Single') !== false) $img_src = '../assets/images/Single Room.jpg';
elseif (strpos($room['room_type'], 'Double') !== false) $img_src = '../assets/images/Double Room.webp';
elseif (strpos($room['room_type'], 'VIP') !== false) $img_src = '../assets/images/VIP Room.jpg';
?>

<div class="container py-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="home.php" class="text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="rooms.php" class="text-decoration-none">Rooms</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $room['room_type']; ?></li>
        </ol>
    </nav>

    <div class="row align-items-start">
        <!-- Room Image & Gallery -->
        <div class="col-lg-7 mb-4">
            <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                <img src="<?php echo $img_src; ?>" class="img-fluid w-100" alt="<?php echo $room['room_type']; ?>" style="max-height: 500px; object-fit: cover;">
            </div>
            
            <div class="mt-4">
                <h4 class="fw-bold text-primary mb-3">Room Amenities</h4>
                <div class="row g-3">
                    <div class="col-6 col-md-4">
                        <div class="d-flex align-items-center bg-white p-3 border rounded shadow-sm">
                            <i class="bi bi-wifi fs-4 text-primary me-3"></i> <span>Free Wi-Fi</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="d-flex align-items-center bg-white p-3 border rounded shadow-sm">
                            <i class="bi bi-tv fs-4 text-primary me-3"></i> <span>Smart TV</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="d-flex align-items-center bg-white p-3 border rounded shadow-sm">
                            <i class="bi bi-snow fs-4 text-primary me-3"></i> <span>AC / Heating</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="d-flex align-items-center bg-white p-3 border rounded shadow-sm">
                            <i class="bi bi-cup-hot fs-4 text-primary me-3"></i> <span>Coffee Maker</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="d-flex align-items-center bg-white p-3 border rounded shadow-sm">
                            <i class="bi bi-safe fs-4 text-primary me-3"></i> <span>Safe Box</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-4">
                <h4 class="fw-bold text-primary mb-3">Description</h4>
                <p class="text-muted lh-lg">
                    Experience luxury and comfort in our spacious <strong><?php echo $room['room_type']; ?></strong>. 
                    Designed with modern aesthetics and premium furnishings, this room offers the perfect retreat 
                    after a long day. Enjoy stunning views, a fully stocked minibar, and a dedicated workspace.
                    Daily housekeeping and 24/7 room service are included to ensure a seamless stay.
                </p>
            </div>
        </div>

        <!-- Booking Form Sidebar -->
        <div class="col-lg-5">
            <div class="card border-0 shadow rounded-3 sticky-top" style="top: 20px; z-index: 100;">
                <div class="card-header bg-primary text-white p-4">
                    <h5 class="mb-0 fw-bold">Book This Room</h5>
                    <p class="mb-0 small opacity-75">Room No: <?php echo $room['room_number']; ?></p>
                </div>
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="text-muted">Price per night</span>
                        <h2 class="text-primary fw-bold mb-0">$<?php echo number_format($room['price_per_night'], 2); ?></h2>
                    </div>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <form action="book_room.php" method="GET"> <!-- Changed to GET for simple handoff to book_room.php logic -->
                            <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                            
                            <div class="mb-3">
                                <label class="form-label fw-bold small text-uppercase text-muted">Check-in Date</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-calendar-check"></i></span>
                                    <input type="date" class="form-control" name="check_in" value="<?php echo $pre_check_in; ?>" min="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label fw-bold small text-uppercase text-muted">Check-out Date</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="bi bi-calendar-x"></i></span>
                                    <input type="date" class="form-control" name="check_out" value="<?php echo $pre_check_out; ?>" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" required>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg fw-bold py-3 shadow-sm transition-hover">
                                    Proceed to Booking <i class="bi bi-arrow-right ms-2"></i>
                                </button>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-warning border-0 d-flex align-items-center" role="alert">
                            <i class="bi bi-exclamation-circle-fill fs-4 me-3"></i>
                            <div>
                                <strong>Login Required</strong><br>
                                You must <a href="../auth/login.php" class="alert-link">login</a> to book this room.
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                             <a href="../auth/login.php" class="btn btn-outline-primary fw-bold">Login</a>
                             <a href="../auth/register.php" class="btn btn-outline-secondary fw-bold">Register</a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-footer bg-light p-3 text-center small text-muted">
                    <i class="bi bi-shield-lock-fill me-1"></i> Secure Booking & Instant Confirmation
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
