<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

// Logic for Filters & Availability (No backend changes, just keeping existing logic wrapped efficiently)
$start_date = isset($_GET['check_in']) ? $_GET['check_in'] : date('Y-m-d');
$end_date = isset($_GET['check_out']) ? $_GET['check_out'] : date('Y-m-d', strtotime('+1 day'));
if ($start_date >= $end_date) {
    $end_date = date('Y-m-d', strtotime($start_date . ' +1 day'));
}

$query = "
    SELECT * FROM rooms 
    WHERE status = 'Available' 
    AND room_id NOT IN (
        SELECT room_id FROM bookings 
        WHERE booking_status != 'Cancelled'
        AND (
            (check_in_date < ? AND check_out_date > ?) 
        )
    )
";
$stmt = mysqli_prepare($conn, $query);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, "ss", $end_date, $start_date);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    // Fallback or error handling
    die("Query Failed: " . mysqli_error($conn));
}
?>

<div class="container py-5">
    <!-- Page Header -->
    <div class="text-center mb-5 animate-fade-in">
        <h2 class="fw-bold text-primary">Find Your Perfect Room</h2>
        <p class="text-muted">Browse our luxurious rooms and suites available for your dates.</p>
    </div>

    <!-- Search/Filter Section -->
    <div class="card shadow-sm mb-5 border-0">
        <div class="card-body bg-white p-4 rounded">
            <h5 class="card-title fw-bold mb-3"><i class="bi bi-calendar-event"></i> Check Availability</h5>
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label text-muted fw-bold">Check-in Date</label>
                    <input type="date" name="check_in" class="form-control form-control-lg" value="<?php echo htmlspecialchars($start_date); ?>" min="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label text-muted fw-bold">Check-out Date</label>
                    <input type="date" name="check_out" class="form-control form-control-lg" value="<?php echo htmlspecialchars($end_date); ?>" min="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold"><i class="bi bi-search"></i> Find Rooms</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Listings -->
    <div class="row g-4">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <?php 
                    // Dynamic Image Selection
                    $img_src = '../assets/images/hotel.webp'; // fallback
                    if (strpos($row['room_type'], 'Single') !== false) $img_src = '../assets/images/Single Room.jpg';
                    elseif (strpos($row['room_type'], 'Double') !== false) $img_src = '../assets/images/Double Room.webp';
                    elseif (strpos($row['room_type'], 'VIP') !== false) $img_src = '../assets/images/VIP Room.jpg';
                ?>
                <div class="col-md-4">
                    <div class="card h-100 shadow border-0 hover-shadow rounded-3 overflow-hidden">
                        <div class="position-relative">
                            <img src="<?php echo $img_src; ?>" class="card-img-top" alt="<?php echo $row['room_type']; ?>" style="height: 250px; object-fit: cover;">
                            <span class="position-absolute top-0 end-0 bg-success text-white px-3 py-1 m-3 rounded-pill fw-bold shadow-sm">
                                Available
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h4 class="card-title fw-bold mb-0"><?php echo htmlspecialchars($row['room_type']); ?></h4>
                                <span class="badge bg-light text-primary border border-primary fs-6">$<?php echo number_format($row['price_per_night'], 0); ?> / night</span>
                            </div>
                            <p class="text-muted small mb-3">Room No: <?php echo htmlspecialchars($row['room_number']); ?></p>
                            
                            <ul class="list-unstyled mb-4 small text-muted">
                                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Free Wi-Fi</li>
                                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Flat Screen TV</li>
                                <li><i class="bi bi-check-circle-fill text-success me-2"></i> Air Conditioning</li>
                            </ul>

                            <div class="d-grid">
                                <a href="room_details.php?id=<?php echo $row['room_id']; ?>&check_in=<?php echo $start_date; ?>&check_out=<?php echo $end_date; ?>" class="btn btn-outline-primary fw-bold">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <div class="alert alert-warning d-inline-block px-5 py-4 shadow-sm">
                    <h4 class="alert-heading fw-bold"><i class="bi bi-exclamation-triangle"></i> No Rooms Found</h4>
                    <p class="mb-0">Please search with different dates.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
