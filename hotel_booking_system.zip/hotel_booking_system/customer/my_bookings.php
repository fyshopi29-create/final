<?php
session_start();
include "../config/db.php";
include '../includes/customer_header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    echo "<script>window.location.href='../auth/login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";
$msg_type = "";

// Handle Cancellation
if (isset($_POST['cancel_booking'])) {
    $booking_id = $_POST['booking_id'];
    
    // Check current status first
    $check_stmt = mysqli_prepare($conn, "SELECT booking_status, room_id, check_in_date, check_out_date FROM bookings WHERE booking_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($check_stmt, "ii", $booking_id, $user_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    $booking_data = mysqli_fetch_assoc($check_result);
    
    if ($booking_data) {
        if ($booking_data['booking_status'] == 'Confirmed') {
             $message = "Cannot cancel a confirmed/paid booking. Please contact support.";
             $msg_type = "warning";
        } elseif ($booking_data['booking_status'] == 'Cancelled') {
             $message = "This booking is already cancelled.";
             $msg_type = "info";
        } else {
            $cancel_stmt = mysqli_prepare($conn, "UPDATE bookings SET booking_status = 'Cancelled' WHERE booking_id = ?");
            mysqli_stmt_bind_param($cancel_stmt, "i", $booking_id);
            
            if (mysqli_stmt_execute($cancel_stmt)) {
                $message = "Booking #$booking_id cancelled successfully.";
                $msg_type = "success";
                
                // Send Email Notification
                $to = $_SESSION['email'] ?? "customer@example.com";
                $subject = "Booking Cancellation - ID $booking_id";
                $body = "Your booking has been cancelled.";
                @mail($to, $subject, $body, "From: no-reply@hotel.com");
            } else {
                $message = "Error cancelling booking.";
                $msg_type = "danger";
            }
        }
    } else {
        $message = "Booking not found.";
        $msg_type = "danger";
    }
}

// Fetch Bookings with Payment Status
$query = "
    SELECT b.booking_id, b.check_in_date, b.check_out_date, b.booking_status, r.room_number, r.room_type, r.price_per_night, r.room_id,
           (SELECT COUNT(*) FROM payments p WHERE p.booking_id = b.booking_id) as is_paid
    FROM bookings b
    JOIN rooms r ON b.room_id = r.room_id
    WHERE b.user_id = ?
    ORDER BY b.booking_id DESC
";
$stmt = mysqli_prepare($conn, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = false;
}
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary"><i class="bi bi-journal-text me-2"></i> My Bookings</h2>
        <a href="rooms.php" class="btn btn-primary rounded-pill px-4 fw-bold"><i class="bi bi-plus-lg"></i> Book New Room</a>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-<?php echo $msg_type; ?> alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-info-circle-fill me-2"></i> <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="py-3 ps-4">ID</th>
                            <th class="py-3">Room Details</th>
                            <th class="py-3">Dates & Duration</th>
                            <th class="py-3">Status</th>
                            <th class="py-3 text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <?php 
                                    // Calc duration
                                    $d1 = new DateTime($row['check_in_date']);
                                    $d2 = new DateTime($row['check_out_date']);
                                    $nights = $d1->diff($d2)->days ?: 1;
                                ?>
                                <tr class="border-bottom">
                                    <td class="ps-4 fw-bold text-muted">#<?php echo $row['booking_id']; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="rounded bg-light p-2 me-3 border">
                                                <i class="bi bi-building fs-4 text-primary"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($row['room_type']); ?></h6>
                                                <small class="text-muted">Room: <?php echo htmlspecialchars($row['room_number']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div><i class="bi bi-calendar-check text-success me-1"></i> <?php echo date("M d, Y", strtotime($row['check_in_date'])); ?></div>
                                            <div><i class="bi bi-calendar-x text-danger me-1"></i> <?php echo date("M d, Y", strtotime($row['check_out_date'])); ?></div>
                                            <div class="text-muted mt-1">(<?php echo $nights; ?> Nights)</div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php 
                                        if ($row['booking_status'] == 'Confirmed') {
                                            echo '<span class="badge bg-success rounded-pill px-3 py-2"><i class="bi bi-check-circle me-1"></i> Confirmed & Paid</span>';
                                        } elseif ($row['booking_status'] == 'Pending') {
                                            echo '<span class="badge bg-warning text-dark rounded-pill px-3 py-2"><i class="bi bi-hourglass-split me-1"></i> Pending Payment</span>';
                                        } elseif ($row['booking_status'] == 'Cancelled') {
                                            echo '<span class="badge bg-secondary rounded-pill px-3 py-2"><i class="bi bi-x-circle me-1"></i> Cancelled</span>';
                                        }
                                        ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <?php if ($row['booking_status'] == 'Pending'): ?>
                                            <a href="payment.php?booking_id=<?php echo $row['booking_id']; ?>" class="btn btn-sm btn-success fw-bold shadow-sm mb-1 mb-lg-0">
                                                Pay Now
                                            </a>
                                            <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this booking?');" style="display:inline-block;">
                                                <input type="hidden" name="booking_id" value="<?php echo $row['booking_id']; ?>">
                                                <button type="submit" name="cancel_booking" class="btn btn-sm btn-outline-danger fw-bold border-0">
                                                    Cancel
                                                </button>
                                            </form>
                                        <?php elseif ($row['booking_status'] == 'Confirmed'): ?>
                                             <a href="invoice.php?booking_id=<?php echo $row['booking_id']; ?>" target="_blank" class="btn btn-sm btn-info text-white fw-bold shadow-sm">
                                                <i class="bi bi-receipt"></i> Invoice
                                             </a>
                                             <a href="add_review.php?room_id=<?php echo $row['room_id']; ?>" class="btn btn-sm btn-outline-secondary fw-bold ms-1">
                                                <i class="bi bi-star"></i> Review
                                             </a>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="bi bi-inbox fs-1 d-block mb-3 opacity-50"></i>
                                        <h4>No Bookings Found</h4>
                                        <p>You haven't made any bookings yet.</p>
                                        <a href="rooms.php" class="btn btn-primary mt-2">Find a Room</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
