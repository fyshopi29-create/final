<?php
// customer/home.php
// Note: Session start is handled in the header include.
include '../includes/customer_header.php';
?>

<!-- 2. Hero Section -->
<header class="hero-section text-white d-flex align-items-center" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('../assets/images/hotel.webp') no-repeat center center/cover; min-height: 80vh;">
    <div class="container text-center">
        <h1 class="display-3 fw-bold mb-3 animate-fade-in">Welcome to Our Hotel</h1>
        <p class="lead mb-4 fs-4">Comfort, Relaxation, and Luxury at your fingertips.</p>
        <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
            <a href="rooms.php" class="btn btn-primary btn-lg px-5 py-3 rounded-pill fw-bold">View Rooms</a>
            <a href="rooms.php" class="btn btn-outline-light btn-lg px-5 py-3 rounded-pill fw-bold">Book Now</a>
        </div>
    </div>
</header>

<!-- 3. About Section -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-8">
                <h2 class="fw-bold mb-4 text-primary">About Our Hotel</h2>
                <p class="text-muted fs-5">
                    Experience the perfect blend of modern luxury and timeless hospitality. 
                    Whether you are traveling for business, planning a family vacation, or looking for a solo retreat, 
                    our hotel offers spacious rooms, world-class amenities, and exceptional service to make your stay unforgettable.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- 4. Rooms Preview Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Rooms</h2>
            <p class="text-muted">Choose comfort that suits your style</p>
        </div>
        <div class="row g-4">
            <!-- Single Room -->
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm hover-shadow">
                    <img src="../assets/images/Single Room.jpg" class="card-img-top" alt="Single Room" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold">Single Room</h5>
                        <p class="card-text text-muted">Perfect for solo travelers. Cozy, modern, and affordable.</p>
                        <a href="rooms.php" class="btn btn-outline-primary rounded-pill mt-2">View Details</a>
                    </div>
                </div>
            </div>
            <!-- Double Room -->
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm hover-shadow">
                    <img src="../assets/images/Double Room.webp" class="card-img-top" alt="Double Room" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold">Double Room</h5>
                        <p class="card-text text-muted">Ideal for couples or friends. Spacious with great amenities.</p>
                        <a href="rooms.php" class="btn btn-outline-primary rounded-pill mt-2">View Details</a>
                    </div>
                </div>
            </div>
            <!-- VIP Room -->
            <div class="col-md-4">
                <div class="card h-100 border-0 shadow-sm hover-shadow">
                    <img src="../assets/images/VIP Room.jpg" class="card-img-top" alt="VIP Room" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold">VIP Suite</h5>
                        <p class="card-text text-muted">Ultimate luxury with premium views and exclusive services.</p>
                        <a href="rooms.php" class="btn btn-outline-primary rounded-pill mt-2">View Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 5. Hotel Services Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Services & Facilities</h2>
            <p class="text-muted">We provide everything you need for a relaxing stay</p>
        </div>
        <div class="row g-4 text-center">
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-moon-stars text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Comfortable Rooms</h5>
                    <p class="small text-muted mb-0">High-quality bedding for best sleep</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-cup-hot text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Restaurant & Coffee</h5>
                    <p class="small text-muted mb-0">Delicious dining all day</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-wifi text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Free Wi-Fi</h5>
                    <p class="small text-muted mb-0">High-speed internet access</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-shield-check text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">24/7 Security</h5>
                    <p class="small text-muted mb-0">Safe and secure environment</p>
                </div>
            </div>
            <!-- Second Row -->
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-water text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Relaxation Area</h5>
                    <p class="small text-muted mb-0">Beautiful gardens and lounges</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-activity text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Gym & Fitness</h5>
                    <p class="small text-muted mb-0">Modern equipment for workouts</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-car-front text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">Car Parking</h5>
                    <p class="small text-muted mb-0">Secure parking space</p>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="p-4 border rounded-3 h-100 shadow-sm">
                    <i class="bi bi-headset text-primary display-4 mb-3"></i>
                    <h5 class="fw-bold">24/7 Support</h5>
                    <p class="small text-muted mb-0">Front desk always available</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 6. Call to Action -->
<section class="py-5 bg-primary text-white text-center">
    <div class="container">
        <h2 class="fw-bold mb-3">Ready to book your stay with us?</h2>
        <p class="lead mb-4">Join us for an unforgettable experience. Sign up today or log in to book.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="../auth/login.php" class="btn btn-light btn-lg rounded-pill px-5 fw-bold text-primary">Login</a>
            <a href="../auth/register.php" class="btn btn-outline-light btn-lg rounded-pill px-5 fw-bold">Register</a>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
